
-- --------------------------------------------------------

--
-- Structure de la table `Comments_Airport`
--

CREATE TABLE `Comments_Airport` (
  `id_comment` int(11) NOT NULL,
  `id_airport` varchar(20) NOT NULL,
  `type_comment` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Comments_Airport`
--

INSERT INTO `Comments_Airport` (`id_comment`, `id_airport`, `type_comment`, `comment`) VALUES
(1, 'AHJ', 'avis', 'An amazing place to visit!'),
(2, 'AHJ', 'information', 'Pas ouvert en hiver!'),
(3, 'AHJ', 'avis', 'An incredible airport!'),
(4, 'ZLXY', 'avis', 'J\'y suis passé plusieurs fois mais je ne comprends toujours pas pourquoi il faut un numéro de portable pour accéder au Wifi?!'),
(5, 'ZBAA', 'avis', '北京国際空港は世界中では有名なの');
