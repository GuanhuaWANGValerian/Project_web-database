
-- --------------------------------------------------------

--
-- Structure de la table `Regions_China`
--

CREATE TABLE `Regions_China` (
  `id` int(6) NOT NULL DEFAULT '0',
  `code` varchar(6) DEFAULT NULL,
  `name_region` varchar(39) DEFAULT NULL,
  `wikipedia_link_region` varchar(43) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Regions_China`
--

INSERT INTO `Regions_China` (`id`, `code`, `name_region`, `wikipedia_link_region`) VALUES
(303422, 'CN-11', 'Beijing Municipality', 'http://en.wikipedia.org/wiki/Beijing'),
(303423, 'CN-12', 'Tianjin Municipality', 'http://en.wikipedia.org/wiki/Tianjin'),
(303424, 'CN-13', 'Hebei Province', 'http://en.wikipedia.org/wiki/Hebei'),
(303425, 'CN-14', 'Shanxi Province', 'http://en.wikipedia.org/wiki/Shanxi'),
(303426, 'CN-15', 'Inner Mongolia Autonomous Region', 'http://en.wikipedia.org/wiki/Inner_Mongolia'),
(303427, 'CN-21', 'Liaoning Province', 'http://en.wikipedia.org/wiki/Liaoning'),
(303428, 'CN-22', 'Jilin Province', 'http://en.wikipedia.org/wiki/Jilin'),
(303429, 'CN-23', 'Heilongjiang Province', 'http://en.wikipedia.org/wiki/Heilongjiang'),
(303430, 'CN-31', 'Shanghai Municipality', 'http://en.wikipedia.org/wiki/Shanghai'),
(303431, 'CN-32', 'Jiangsu Province', 'http://en.wikipedia.org/wiki/Jiangsu'),
(303432, 'CN-33', 'Zhejiang Province', 'http://en.wikipedia.org/wiki/Zhejiang'),
(303433, 'CN-34', 'Anhui Province', 'http://en.wikipedia.org/wiki/Anhui'),
(303434, 'CN-35', 'Fujian Province', 'http://en.wikipedia.org/wiki/Fujian'),
(303435, 'CN-36', 'Jiangxi Province', 'http://en.wikipedia.org/wiki/Jiangxi'),
(303436, 'CN-37', 'Shandong Province', 'http://en.wikipedia.org/wiki/Shandong'),
(303437, 'CN-41', 'Henan Province', 'http://en.wikipedia.org/wiki/Henan'),
(303438, 'CN-42', 'Hubei Province', 'http://en.wikipedia.org/wiki/Hubei'),
(303439, 'CN-43', 'Hunan Province', 'http://en.wikipedia.org/wiki/Hunan'),
(303440, 'CN-44', 'Guangdong Province', 'http://en.wikipedia.org/wiki/Guangdong'),
(303441, 'CN-45', 'Guangxi Autonomous Region', 'http://en.wikipedia.org/wiki/Guangxi'),
(303442, 'CN-46', 'Hainan Province', 'http://en.wikipedia.org/wiki/Hainan'),
(303443, 'CN-50', 'Chongqing Municipality', 'http://en.wikipedia.org/wiki/Chongqing'),
(303444, 'CN-51', 'Sichuan Province', 'http://en.wikipedia.org/wiki/Sichuan'),
(303445, 'CN-52', 'Guizhou Province', 'http://en.wikipedia.org/wiki/Guizhou'),
(303446, 'CN-53', 'Yunnan Province', 'http://en.wikipedia.org/wiki/Yunnan'),
(303447, 'CN-54', 'Tibet Autonomous Region', 'http://en.wikipedia.org/wiki/Tibet'),
(303448, 'CN-61', 'Shaanxi Province', 'http://en.wikipedia.org/wiki/Shaanxi'),
(303449, 'CN-62', 'Gansu Province', 'http://en.wikipedia.org/wiki/Gansu'),
(303450, 'CN-63', 'Qinghai Province', 'http://en.wikipedia.org/wiki/Qinghai'),
(303451, 'CN-64', 'Ningxia Autonomous Region', 'http://en.wikipedia.org/wiki/Ningxia'),
(303452, 'CN-65', 'Xinjiang Autonomous Region', 'http://en.wikipedia.org/wiki/Xinjiang'),
(303453, 'CN-71', 'Taiwan (disputed)', 'http://en.wikipedia.org/wiki/Taiwan'),
(303454, 'CN-91', 'Hong Kong Special Administrative Region', 'http://en.wikipedia.org/wiki/Hong_Kong'),
(303455, 'CN-92', 'Macau Special Administrative Region', 'http://en.wikipedia.org/wiki/Macau'),
(303456, 'CN-U-A', '(unassigned)', '');
