
--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Airports_China`
--
ALTER TABLE `Airports_China`
  ADD PRIMARY KEY (`ident`);

--
-- Index pour la table `Comments_Airport`
--
ALTER TABLE `Comments_Airport`
  ADD PRIMARY KEY (`id_comment`);

--
-- Index pour la table `Regions_China`
--
ALTER TABLE `Regions_China`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Comments_Airport`
--
ALTER TABLE `Comments_Airport`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;